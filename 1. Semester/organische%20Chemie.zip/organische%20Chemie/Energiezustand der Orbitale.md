- kann mathematisch berechnet werden, und graphisch dargestellt werden:
![](Pasted%20image%2020231016161451.png)
