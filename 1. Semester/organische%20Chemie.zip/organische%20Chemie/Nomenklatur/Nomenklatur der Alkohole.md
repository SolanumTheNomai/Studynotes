- Stammalkan: längste Kette, welche die OH-Gruppe trägt:
![](Pasted%20image%2020231030163349.png)
- Zählweise: zählt vom Ende, welche der OH-Gruppe am nächsten ist:
![](Pasted%20image%2020231030163428.png)
- Bei Molekülen mit funktionellen Gruppen mit höherer Priorität wird das Präfix "Hydroxy-" verwendet + man beginnt bei Funktionellen Gruppen höherer Priorität an zu zählen 