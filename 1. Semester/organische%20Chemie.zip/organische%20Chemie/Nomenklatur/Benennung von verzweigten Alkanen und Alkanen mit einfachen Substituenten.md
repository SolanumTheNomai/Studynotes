1. längste Kohlenstoffkette finden 
	1.1 bei zwei oder mehr Ketten gleicher Länge --> diejenige Kette mit den meisten Substituenten 

2. Nummerierung der C-Atome, beginnend am Ende, das einem Substituenten am nächsten ist 
3. Bennennung der Substituenten
4. Namen der Substituenten + Nummer in alphabetischer Reihenfolge und den Stammalkan dahinter 