![](Pasted%20image%2020231030163738.png)
