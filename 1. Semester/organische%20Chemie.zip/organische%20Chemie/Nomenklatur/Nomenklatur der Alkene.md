1. längste Kette mit Doppelbindungen suchen 
2. Nummerierung der Kette: welcher der DB am nächsten ist --> Lage des DB wird nummierert (z.B. 2 Buten)


- cis/trans-Nomenklatur:
	- nur bei Alkenen die jeweils nur einen Substituenten besitzen:
![](Pasted%20image%2020231211184452.png)


- E/Z-Nomenklatur:
	- bei Alkenen, deren Doppelbindungen mehrere Substituenten besitzen 
	![](Pasted%20image%2020231211184649.png)
	![](Pasted%20image%2020231211184657.png)
	