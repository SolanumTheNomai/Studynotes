- Aldehyde:
	- Alkan-nal --> Suffix
	- Oxo- --> Präfix

- Ketone:
	- Alkan-on --> Suffix
	- Oxo- --> Präfix