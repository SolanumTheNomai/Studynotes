- sorgen für ein Gleichgewicht zwischen Atomen, wobei diese zu [[Molekülen]] zusammengehalten werden 

- Arten von chemischen Bindungen: 
	- [[StudyNotes/1. Semester/organische Chemie/Ionische Bindung]] 
	- [[kovalente Bindungen]]
	- [[Metallische Bindung]]