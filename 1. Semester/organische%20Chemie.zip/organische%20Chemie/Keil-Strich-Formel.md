![[Pasted image 20231009165427.png]]
- dicke Kegelstrukturen zeigen zum Beobachter hin
- gestrichelte Kegelstrukturen zeigen vom Beobachter weg