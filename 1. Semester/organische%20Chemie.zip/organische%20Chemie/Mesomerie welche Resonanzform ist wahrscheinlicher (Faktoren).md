1. Resonanzformeln mit der meisten Atomen, welche die Elektronenoktettregel erfüllt haben 
2. neg. Ladung eher an Atomen mit größten [Elektronenegativität](Elektronenegativität.md) und andersherum
3. Resonanzformeln mit geringer Ladungstrennung 