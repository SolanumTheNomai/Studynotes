![](Pasted%20image%2020240108192654.png)
