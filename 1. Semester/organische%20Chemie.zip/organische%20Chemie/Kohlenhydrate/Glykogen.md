- Reserve-Polysaccharid für Tiere
- a(1->4) glykosidische Bindung mit a(1->6) Verzweigungen (alle 8-12 Glucoseeinheiten) --> helikale Konformation 
![](Pasted%20image%2020240111171608.png)
