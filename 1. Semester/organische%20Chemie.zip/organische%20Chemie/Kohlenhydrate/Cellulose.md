- D-Glucoseeinheiten, mit ß(1->4)-glykosischen Bindungen --> Substituenten, wo die Bindungen stattfinden sind äquatorial angeordnet --> lineare Konformation:
![](Pasted%20image%2020240111170323.png)
--> mehrere Celluloseketten ordnen sich parallel an, wobei sie mittels H-Brücken intermolekular miteinander wechselwirken:
![](Pasted%20image%2020240111170557.png)
--> durch ihre kompakte Struktur: nicht wasserlöslich