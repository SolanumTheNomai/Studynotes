![](Pasted%20image%2020240108184031.png)
![](Pasted%20image%2020240108184045.png)
