- Pyranose: sechsgliedrige Ringform eines Zuckers:
![](Pasted%20image%2020240108191201.png)

- Furanose: fünfgliedrige Ringform eines Zuckers:
![](Pasted%20image%2020240108191229.png)
