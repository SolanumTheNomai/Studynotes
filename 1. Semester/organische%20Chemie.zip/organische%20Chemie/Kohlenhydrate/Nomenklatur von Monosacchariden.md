- Wenn Zucker eine Aldehydgruppe besitzt --> Aldosen
- Wenn Zucker eine Ketogruppe besitzt --> Ketosen

- Anzahl an C-Atomen:
	--> Triosen
	--> Tetrose
	--> Pentose
	--> usw.