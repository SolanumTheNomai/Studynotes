- Struktur-Polysaccharide (z.B. Cellulose)
- Wasserbindende Polysaccharide (Stärke, Glykogen)
- Reserve-Polysaccharide (Stärke, Glykogen)

