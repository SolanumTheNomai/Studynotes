- Kondensationsreaktion:
![](Pasted%20image%2020240108191944.png)
--> energetisch ungünstig --> Enzym mit ATP-Verbrauch notwendig:

- Phosphorylierung der Glucosemoleküle:
![](Pasted%20image%2020240108192410.png)
--> beide Glucosemoleküle werden mittels Enzym Hydrolysiert:
--> Maltose + 2 Phosphate