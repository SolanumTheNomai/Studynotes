![](Pasted%20image%2020240108183213.png)
