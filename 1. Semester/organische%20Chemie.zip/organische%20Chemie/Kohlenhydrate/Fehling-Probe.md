- Nachweis von Aldehyden, sowie Saccharide mit Aldehydgruppen durch deren Oxidation in Carbonsäuren und Reduktion von Kupferionen:
![](Pasted%20image%2020240108194523.png)
--> falls es zur Reduktion kommt --> roter Niederschlag des reduzierten Kupfermoleküls 


positive Beispiele:
![](Pasted%20image%2020240108195945.png)
--> geringe Konzentration von der offenkettige Form der Zucker --> haben Aldehydgruppen --> Reaktion zur Carbonsäure --> weniger offenkettige Zuckerform --> Umwandlung von Cyklischer Zuckerform zur offenkettigen 
--> Prozess wiederholt sich 

