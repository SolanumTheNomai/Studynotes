- liegen als cyclische Halbacetale/Halbketale vor:
- Mechanismus:
![](Pasted%20image%2020240108185212.png)
--> Protonierung der Carbonylgruppe --> Carbeniumion --> Nucleophiler Angriff der 5. Hydroxygruppe --> pos. geladenes Sauerstoff --> Deprotonierung --> Halb-Acetal/Halb-Ketal 

- Grund für das Halb-Acetal/-Ketal:
	- Reaktion ist eine Kondensation --> in der wässrigen Umgebung ungünstig 
