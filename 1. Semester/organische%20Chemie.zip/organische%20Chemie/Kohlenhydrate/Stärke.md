- pflanzliches Reservepolysaccharid 
- Gemisch aus a-Amylose und Amylopektin:

**a-Amylose** 
- Verknüpft durch a(1->4)-glykosidischen Bindungen 
![](Pasted%20image%2020240111170839.png)
--> Substituent wo die Bindung stattfindet axial angeordnet --> helikale Konformation:
![](Pasted%20image%2020240111171014.png)


**Amylopektin** 
![](Screenshot%202024-01-11%20171100.png)
- a(1->4) Bindungen + a(1->6) Verknüpfungen --> Verzweigung alle 24- bis 30 Glucoseeinheiten