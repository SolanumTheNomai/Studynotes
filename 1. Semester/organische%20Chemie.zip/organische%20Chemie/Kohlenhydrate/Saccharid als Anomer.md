- bei der Cyclierung --> neues Stereozentrum --> zwei Isomermöglichkeiten durch die Cyclisierung: a- und ß-Form:
![](Pasted%20image%2020240108185846.png)
--> Lage der OH-Gruppe am 1. C-Atom 

- Gleichgewicht bei D-Glucose:
![](Pasted%20image%2020240108190349.png)
--> Grund für mehr ß-Anomere: 
	- OH-Gruppe in der äquatorialen Anordnung --> geringere sterische Hinderung:
![](Pasted%20image%2020240108190618.png)
