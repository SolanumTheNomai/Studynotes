- Energiespeicher (z.B. Stärke)
--> Brennstoff für die Zelle (z.B. Glucose)

- strukturelle Grundstoffe (z.B. Cellulose, Chitin)

- Erkennungsprozesse (z.B. Glykoproteine)

