- Prozess, wo Saccharide (meist: Pyranose) mit reinen Anomerkonzentration ihren Drehwinkel ändern, da sich ein chemisches Gleichgewicht zwischen den Anomerkonzentrationen ausbildet

