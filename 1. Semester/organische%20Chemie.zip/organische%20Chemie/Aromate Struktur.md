- beteiligten Atome sind sp2-hybridisiert 
- p-Orbitale stehen für das pi-System zur Verfügung
--> planares, cyclisch durchkonjugiertes pi-System (Elektronen sind in diesem System delokalisiert)
![](Pasted%20image%2020231023174551.png)

- müssen insgesamt (4n+2) pi-Elektronen besitzen 