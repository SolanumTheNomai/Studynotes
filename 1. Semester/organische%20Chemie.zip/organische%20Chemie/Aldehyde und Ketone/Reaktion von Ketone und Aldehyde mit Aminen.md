![](Pasted%20image%2020231221173732.png)
- Nucleophil greift C-Atom an --> Doppelbindung mit Sauerstoff löst sich auf --> neg. geladenes Sauerstoff, pos. geladener Stickstoff --> Protonen lagern sich am Sauerstoff an --> C-N Doppelbindung mit Wasserabspaltung (Kondensationsreaktion)
![](Pasted%20image%2020231221175219.png)

- Entstehung von Enamin:
![](Pasted%20image%2020231221175400.png)
- Nucleophil greift C-Atom an --> Doppelbindung mit Sauerstoff löst sich auf --> neg. geladenes Sauerstoff, pos. geladener Stickstoff --> Protonen lagern sich am Sauerstoff an --> Alkenbindung mit Wasserabspaltung