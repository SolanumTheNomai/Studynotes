Isomere, die sich in der Lage der Doppelbindung und des Protons unterscheiden 
![](Pasted%20image%2020231221173302.png)
