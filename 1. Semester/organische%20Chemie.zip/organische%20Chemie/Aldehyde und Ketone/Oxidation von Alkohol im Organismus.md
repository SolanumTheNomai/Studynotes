![](Pasted%20image%2020231221165541.png)
--> Proton und Hydrid wird aus dem Alkohol elimiert --> NAD+ wird zu NADH + H+ --> Oxidation von Alkohol zum Aldehyd


![](Pasted%20image%2020231221165729.png)
--> Hydrid wird aus dem Aldehyd eliminiert --> Substitution mit OH- des Wassers --> Hydrid und Proton auf das Oxidationsmittel NAD+
--> Entstehung einer Carbonsäure 