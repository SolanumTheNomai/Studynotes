![](Pasted%20image%2020231221163555.png)
--> aus einem primären Alkohol kann man Aldehyde herstellen (Dehydrierung):
- Oxidationsmittel:  ![](Pasted%20image%2020231221164039.png)

--> aus Aldehyden kann man Carbonsäuren herstellen (Substitution von H und OH)
- Oxidationsmittel: 
![](Pasted%20image%2020231221164236.png)



![](Pasted%20image%2020231221164328.png)
--> aus sekundären Alkohol kann man Ketone herstellen (Dehydrierung)
