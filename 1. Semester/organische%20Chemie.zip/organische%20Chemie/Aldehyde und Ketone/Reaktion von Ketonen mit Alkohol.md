- werden zu Vollketale:
![](Pasted%20image%2020240104115527.png)
(analoger Reaktionsmechanismus wie bei Aldehyden):
![](Pasted%20image%2020240104115629.png)

