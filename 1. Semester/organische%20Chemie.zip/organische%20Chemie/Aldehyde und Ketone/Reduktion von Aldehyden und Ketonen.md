- Rückreaktion der Oxidation --> in primäre-/sekundäre Alkohole:
![](Pasted%20image%2020231221170857.png)

- bedeutendes Reduktionsmittel:
- Natriumborhydrid:
![](Pasted%20image%2020231221172010.png)
--> Hydrid greift als Nucleophil das elektrophile C-Atom der Carbonylgruppe an --> neg. geladene Verbindung --> mit einem Alkohol --> Proton wird abgespalten --> Entstehung eines Alkohols --> OR- Rest bindet an das Natrium + BH3 --> reagiert evtl zu:
![](Pasted%20image%2020231221172421.png)

--> insgesamt: Hydrierung 