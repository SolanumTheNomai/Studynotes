- Prinzip: Iminbildung --> Reduktion zum Amin:
![](Pasted%20image%2020240104114357.png)
- aus dem Imin --> Hydrierung --> Proton lagert sich am Stickstoff an --> Stickstoff pos. geladen --> zieht die DB zu sich --> Carbeniumion --> Hydrid lagert sich an 