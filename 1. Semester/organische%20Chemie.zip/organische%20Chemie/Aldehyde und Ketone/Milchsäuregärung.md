![](Pasted%20image%2020231221172611.png)
![](Pasted%20image%2020231221172630.png)
- Hydrid von NADH wird abgegeben und greift das C-Atom des Pyruvats an --> Doppelbindung zwischen Sauerstoff und Kohlenstoff löst sich --> neg. geladen --> Proton des NADH+ H+ bindet an den Sauerstoff --> L-Lactat als Alkohol + NAD+ 