- bei Aldehyden --> werden zu Vollacetale:
![](Pasted%20image%2020240104114835.png)
--> durch H+ --> pos. geladener Sauerstoff --> Mesomerie --> Carbeniumion --> Alkohol bindet --> Protonabspaltung aufgrund der pos. geladenen Hydroxygruppe --> **Halbacetal** 

--> durch H+ --> pos. geladener Sauerstoff --> Wasserabspaltung --> Carbeniumion --> Alkohol lagert sich an --> Protonenabspaltung --> **Vollacetal** 
![](Pasted%20image%2020240104115442.png)
