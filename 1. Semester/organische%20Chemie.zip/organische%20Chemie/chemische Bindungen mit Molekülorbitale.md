- wenn keine Energie ins System hinzugefügt wird, gehen Atome dann Bindungen ein, wenn dadurch das Energieniveau der Elektronen sinkt:
![](Pasted%20image%2020231016161914.png)
--> wenn sich zwei Atomorbitale überlappen --> wenn sich die Elektronenwellenfunktionen in Phase befinden --> Erhöhung der Elektronendichte an der Überlappung --> Elektronen befinden sich zwischen den Atomkernen --> Atomkerne werden vom Elektronenzentrum angezogen 
--> Entstehung eines bindenden Molekülorbitals