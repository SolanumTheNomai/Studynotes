![](Pasted%20image%2020240115184409.png)
erste Zahl: Anzahl der C-Atome
zweite Zahl: Anzahl der C=C Doppelbindung
in den Klammern: Ort der Doppelbindung (meist: cis)