- Spaltung der Esterbindung durch Basen und thermischer Energie:
![](Pasted%20image%2020240122181938.png)
--> Entstehung von Seifen (Tenside) 
--> sind Amphiphile



