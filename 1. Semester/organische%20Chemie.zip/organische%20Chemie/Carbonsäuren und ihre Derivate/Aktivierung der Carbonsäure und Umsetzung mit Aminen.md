- Umsetzung der Carbonsäure mit einer Kupplungsreagenz --> OH-Gruppe wird in eine gute Abgangsgruppe überführt --> "Aktivierung der Carbonsäure"
- wichtig: Zugabe einer Base damit ein Caboxylat entsteht:
![](Pasted%20image%2020240122182658.png)
--> bessere Abgangsgruppe --> Additions-Eliminierungs-Mechanismus mit Amin möglich:
![](Pasted%20image%2020240122182752.png)
