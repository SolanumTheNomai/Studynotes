- bei Aminosäuren:
	- in ihrer Zwitterionenform schlechter löslich:
![](Pasted%20image%2020240118120327.png)
--> AS lagern sich in der ZIF an --> keine Hydrathülle


- bei Proteinen:
	- beim pI besonders niedrig:
![](Pasted%20image%2020240118120447.png)
