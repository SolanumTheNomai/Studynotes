![](Pasted%20image%2020240111171818.png)
