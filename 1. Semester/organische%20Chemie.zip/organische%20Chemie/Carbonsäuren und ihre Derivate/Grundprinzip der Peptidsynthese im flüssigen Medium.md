- damit ein Peptid mit den AS in der richtigen Reihenfolge reagiert soll --> einige funktionelle Gruppen müssen vor Reaktionen geschützt werden 

1. Aktivierung der Carboxygruppe 
2. für weitere Anknüpfungen --> Schutzgruppe muss **selektiv** abgespalten werden 

