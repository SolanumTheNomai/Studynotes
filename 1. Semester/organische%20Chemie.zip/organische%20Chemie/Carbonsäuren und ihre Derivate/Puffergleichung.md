![](Pasted%20image%2020240115190106.png)
--> pKs = Mengenverhältnis von schwache Säure und konjugierte Base 1:1