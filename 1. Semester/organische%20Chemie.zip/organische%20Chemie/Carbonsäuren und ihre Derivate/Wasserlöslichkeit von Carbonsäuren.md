- Löslichkeit sinkt mit steigender Kettenlänge, wobei bei C < 5 die Säuren vollständig löslich sind

- die Löslichkeiten von den Salzen ist wesentlich höher:
![](Pasted%20image%2020240118120129.png)
--> höherer pH-Wert --> höhere Löslichkeit