- ohne weiteres: Säure Base Reaktion, ohne die Entstehung eines Amids:
![](Pasted%20image%2020240122182221.png)
