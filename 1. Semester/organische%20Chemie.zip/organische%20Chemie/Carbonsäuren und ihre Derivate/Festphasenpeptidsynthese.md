1. Verankerung der Aminosäure mit geschützter Aminogruppe an der festen Phase:
![](Pasted%20image%2020240122183823.png)
2. Entschützung der Aminogruppe der 1. Aminosäure: 
![](Pasted%20image%2020240122183948.png)
3. Kupplung der 2. AS mit geschützter Aminogruppe:
![](Pasted%20image%2020240122184045.png)
4. Prozess iteriert 
5. Abspaltung vom Harz:
![](Pasted%20image%2020240122184152.png)
