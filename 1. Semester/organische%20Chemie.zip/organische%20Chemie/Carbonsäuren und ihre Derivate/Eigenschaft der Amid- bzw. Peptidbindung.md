- Doppelbindung an der Carbonylgruppe kann zur C-N-Bindung übergehen --> partieller Doppelbindungscharakter:
![](Pasted%20image%2020240122183022.png)
--> durch die DB --> planare Konformation --> Konformation von Peptiden relativ unflexibel 
