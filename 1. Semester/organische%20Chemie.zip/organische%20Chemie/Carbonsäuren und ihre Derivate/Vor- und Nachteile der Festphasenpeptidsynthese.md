- Vorteile:
	- Einsatz von hohen Überschuss an spezifischen Reagenzien möglich, da nicht umgesetzte Reagenzien einfach durch Filtrieren und Waschen entfernt werden können --> hohe Ausbeute:
![](Pasted%20image%2020240216134359.png)
--> Automatisierung möglich

- Nachteile:
	- Reaktivität eingeschränkt, da die Reaktion nur an der Oberfläche der Festphase abläuft 
	- da die Reaktion an der festen Phase gebunden ist --> einfache analytische Methoden, wie die Dünnschichtchromatographie sind für die Reaktionskontrolle nicht möglich 
	- benötigt große Mengen an Trägermaterial (Harz)