![](Pasted%20image%2020240111171848.png)
