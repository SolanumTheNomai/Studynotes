![](Pasted%20image%2020240118121716.png)

- Reaktivität der Derivate:
![](Pasted%20image%2020240118121749.png)
--> Abhängig vom Derivat 