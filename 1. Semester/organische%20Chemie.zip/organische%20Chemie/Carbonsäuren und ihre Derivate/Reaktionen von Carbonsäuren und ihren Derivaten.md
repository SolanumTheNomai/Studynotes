![](Pasted%20image%2020240118121501.png)
--> zuerst: Addition eines Nucleophils --> tetraedrische Zwischenstufe --> Eliminierung (Abgangsgruppe)

**Additions-Eliminierungs-Mechanismus** 