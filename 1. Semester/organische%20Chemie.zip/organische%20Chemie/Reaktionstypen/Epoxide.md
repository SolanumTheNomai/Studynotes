- Verbindungen, eines Dreirings mit einem Sauerstoffatom 
--> aufgrund der Ringspannung --> Epoxide reagieren leicht mit Nucleophilen unter Ringöffnung:
![](Pasted%20image%2020231207114801.png)
