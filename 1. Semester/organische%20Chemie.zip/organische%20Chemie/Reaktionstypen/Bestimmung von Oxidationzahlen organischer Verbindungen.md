- Alle Bindungselektronen werden den Bindungspartner zugeordnet mit höherer EN 
- Bei Bindungen zweier gleichen Atomen bekommt jeder Bindungspartner ein Elektron 
--> Vergleich von eigentlichen Valenzelektronen des Atoms mit den zugeordneten Valenzelektronen:
	- mehr VE als normal --> negative Oxidationszahl
	- weniger VE als normal --> positive Oxidationszahl:
![](Pasted%20image%2020231116174947.png)
