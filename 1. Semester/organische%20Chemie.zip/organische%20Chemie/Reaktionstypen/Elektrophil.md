- elektronenliebendes Teilchen 
--> Elektronenpaarakzeptoren --> haben positive Ladungen/pos. Partialladung --> werden von Nucleophilen "angegriffen"
![](Pasted%20image%2020231123144736.png)
