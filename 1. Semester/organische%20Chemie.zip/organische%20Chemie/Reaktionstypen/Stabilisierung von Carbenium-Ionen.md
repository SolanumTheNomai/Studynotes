- Carbenium-Ionen besitzen nur 6 Valenzelektronen --> Elektronenlücke --> reaktiv 

- ABER: Hyperkonjugation:
	- Überlappung von gefüllten Orbitalen einer sigma-Bindung mit teilweise oder leeren p-Orbitalen --> Elektronen gehen teilweise in die "Elektronenlücke rüber" --> Delokalisation der Elektronendichte --> Mesomeriestabilisierung:
![](Pasted%20image%2020231130161852.png)
--> je mehr Orbitale von Substituenten mit dem p-Orbital eine Hyperkonjugation durchführen kann, desto stabiler ist es --> schnellere Bildung der Zwischenstufe 
![](Pasted%20image%2020231130162517.png)
