![](Pasted%20image%2020231123135949.png)
k = Geschwindigkeitskonstante: 
![](Pasted%20image%2020231123140145.png)
--> Geschwindigkeit von der Menge des Edukts abhängig

--> bei sinkender Aktivierungsenergie Ea --> höhere Reaktionsgeschwindigkeit 
--> bei steigender Temperatur T --> höhere Reaktionsgeschwindigkeit 
