- hohe Reaktionsgeschwindigkeit 
- Abhängig von:
	- Ladung: 
		- Anionen sind besser als ungeladene Teilchen:
		![](Pasted%20image%2020231127162656.png)
		- !Achtung!: nur Verbindungen mit ähnlichen Atomen vergleichen
	- Polarisierbarkeit:
		- angreifende Atome mit geringerer Elektronegativität ist besser, da sie leichter polarisierbar sind --> bessere Nucleophile 
		![](Pasted%20image%2020231127163001.png)
	- sterische Hinderung 
		- Moleküle mit kleineren sterischen Hinderungen nach der Substitution sind bessere Nucleophile