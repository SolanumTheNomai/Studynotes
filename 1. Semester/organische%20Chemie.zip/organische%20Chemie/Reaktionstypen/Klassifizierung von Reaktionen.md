- Parameter: Strukturelle Änderungen 
![](Pasted%20image%2020231116173955.png)
- S: eine Verbindung wurde durch eine andere ersetzt
- A: Verbindungen kamen hinzu
- E: Verbindungen wurden aus dem Molekül abgezogen
- R: Bildung eines Isomers

