- "kernliebende" Teilchen --> fühlen sich zu positiven Ladungen/Partialladungen "angezogen"
--> besitzen ein **Elektronenpaar**, dass sie dem Reaktionspartner (Verbindung mit einen Elektrophilen Atom) zur Verfügung stellen können 
![](Pasted%20image%2020231123144313.png)
