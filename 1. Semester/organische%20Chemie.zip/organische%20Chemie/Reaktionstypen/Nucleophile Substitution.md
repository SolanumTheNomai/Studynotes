 - Eine Verbindung mit einem Elektrophilen Atom, geht mit einer nucleophilen-Verbindung eine Substitutionsreaktion ein --> Entstehung einer Abgangsgruppe als "Nebenverbindung"
 ![](Pasted%20image%2020231123144026.png)
 