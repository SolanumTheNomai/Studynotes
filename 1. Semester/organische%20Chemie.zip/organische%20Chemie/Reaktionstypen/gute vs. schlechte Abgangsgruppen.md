- Gute Abgangsgruppen können schlechte Abgangsgruppen "verdrängen" --> Reaktion zur guten Abgangsgruppe begünstigt:
![](Pasted%20image%2020231127162522.png)
