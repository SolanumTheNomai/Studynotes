- Addition von Wasserstoff (H2) --> Spaltung einer Einfachbindung:
![](Pasted%20image%2020231123135910.png)
