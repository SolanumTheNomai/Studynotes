- Doppel- und Einfachbindungen wechseln sich ab 
![](Pasted%20image%2020231214171342.png)
--> delokalisiertes pi-Elektronensystem, mit pi-Bindungen und schwachen pi-Überlappungen durch die benachbarten p-Orbitale:
![](Pasted%20image%2020231214171436.png)
- gleichzeitig: mehrere Mesomere Formen --> Mesomeriestabilisierung
--> diese Moleküle sind thermodynamisch sehr stabil

- durch die schwachen pi-Überlappungen --> eingeschränkte Rotation des Moleküls + verkürzte Einfachbindung
