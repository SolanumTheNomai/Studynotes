1. alle Oxidationen und Reduktionen in der Reaktion ermitteln 
2. Elektronentransfer ermitteln
3. Verhältnisse anpassen, sodass: aufgenommende Elektronen = abgegebene Elektronen 

