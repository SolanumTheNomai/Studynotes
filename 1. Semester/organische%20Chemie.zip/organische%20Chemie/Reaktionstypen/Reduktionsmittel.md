- Verbindungen, welche andere zur Reduzierung anderer Stoffe führt --> Elektronendonator 

![](Pasted%20image%2020231120161354.png)


