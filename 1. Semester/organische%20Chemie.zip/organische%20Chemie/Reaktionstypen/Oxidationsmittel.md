- Verbindungen, welche andere Stoffe oxidieren --> Elektronenakzeptor

![](Pasted%20image%2020231120161337.png)



