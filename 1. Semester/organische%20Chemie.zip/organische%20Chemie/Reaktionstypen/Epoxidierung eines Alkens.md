![](Pasted%20image%2020231214170713.png)
- Sauerstoff der Persäure wird auf das Alkan übertragen --> Entstehung eines Epoxids und Carbonsäure 