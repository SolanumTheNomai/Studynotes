- Substituent mit der höchsten Elektronegativität wird ausgetauscht und wird zur Abgangsgruppe (Anion, kann die negative Ladung gut stabilisieren):
![](Pasted%20image%2020231127162049.png)

- schwache Basen:
![](Pasted%20image%2020231127162200.png)
