- Addition von H2O an die Doppelbindung eines organischen Moleküls --> dabei wird eine H-O Bindungs des Wassers gespalten:
![](Pasted%20image%2020231123133948.png)
