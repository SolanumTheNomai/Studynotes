- Wasseranlagerung an ein Ion:
![](Pasted%20image%2020231123134405.png)
