![](Pasted%20image%2020231214165844.png)
- Bsp: Halogenid
![](Pasted%20image%2020231214174353.png)
- Bsp: Wasser 
	- verdünnte Phosphor-/Schwefelsäure --> hoher Wassergehalt --> Hydratisierung vereinfacht


- Markownikow-Regel:
	- Bei der Addition von HX/H2O an einem Alken --> Proton addiert sich immer an das C-Atom die mehr H-Atome besitzen --> stabilere Zwischenstufe
![](Pasted%20image%2020231214170147.png)
