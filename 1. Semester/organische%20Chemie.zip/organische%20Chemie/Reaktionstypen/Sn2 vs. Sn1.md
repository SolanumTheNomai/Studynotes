- Abhängig von der Klassifizierung des C-Atoms, an der Abgangsgruppe:
![](Pasted%20image%2020231130163245.png)
