- während der Substitution wird kein Zwischenprodukt gebildet --> einstufig (konzertiert)
- Reaktionsgeschwindigkeit ist Abhängig von zwei Teilchen (Edukt, Nucleophil) (bimolekulekular):
![](Pasted%20image%2020231127163956.png)

--> Rückseitenangriff --> Inversion der Konfiguration (falls Enantiomer: von r-Form zur s-Form)


