![](Pasted%20image%2020231214164924.png)
![](Pasted%20image%2020231214165030.png)
- Katalysator:
	- Pd/C --> Palladium auf Aktivkohle
	- Platin
	- Nickel:
	![](Pasted%20image%2020231214165118.png)

- Wasserstoff lagert sich einzeln auf der Oberfläche des Katalysators an 
- Intermolekulare WW zwischen Alken und Katalysator --> Senkung der Aktivierungsenergie zur Hydrierung --> Alkan 