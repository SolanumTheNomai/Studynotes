- im Labor: 
![](Pasted%20image%2020231211184950.png)
--> E1-Reaktion 

![](Pasted%20image%2020231211185013.png)
--> E2-Reaktion 