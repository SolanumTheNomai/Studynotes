- Addition von Wasserstoff (H2) an eine Doppelbindung:
![](Pasted%20image%2020231123134546.png)
