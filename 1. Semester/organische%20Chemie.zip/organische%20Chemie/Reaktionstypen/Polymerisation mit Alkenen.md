![](Pasted%20image%2020231218181449.png)
