- Stoff, welcher die Geschwindigkeit einer chemischen Reaktion erhöht, ohne selbst verbraucht zu werden und ohne die entgültige Lage des thermodynamischen Gleichgewichts dieser Reaktion zu verändern --> chemisches Gleichgewicht ändert sich nicht, es wird nur schneller erreicht

- Grund: Senkung der Aktivierungsenergie Ea:
![](Pasted%20image%2020231123142215.png)
