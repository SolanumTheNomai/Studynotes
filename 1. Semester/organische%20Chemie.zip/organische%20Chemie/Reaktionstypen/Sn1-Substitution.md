- Carbeniumion als Zwischenstufe 
![](Pasted%20image%2020231130160928.png)
--> Reaktionsgeschwindikeit hängt nur von der Konzentration des Eduktes ab, da das Carbeniumion für die Substitution notwendig ist (unimolekularer Prozess)
![](Pasted%20image%2020231130161120.png)
- wenn im Edukt Stereozentren vorhanden sind: Racemisierung
![](Pasted%20image%2020231130161335.png)
