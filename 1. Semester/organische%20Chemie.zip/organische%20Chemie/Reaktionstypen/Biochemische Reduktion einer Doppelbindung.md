![](Pasted%20image%2020231214165650.png)
