- Eliminierung von Wasser aus dem organischen Molekül unter Ausbildung einer Doppelbindung 
![](Pasted%20image%2020231123134338.png)
