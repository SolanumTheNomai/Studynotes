- besitzen zwei Schwefelatome mit zwei Resten
--> Entstehen z.B. bei Disulfidbrücken von Proteinen und Peptiden 
![](Pasted%20image%2020231026170933.png)
