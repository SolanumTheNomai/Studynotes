- keine funktionellen Gruppen 
- unpolar, wenig reaktiv aber brennbar 
![](Pasted%20image%2020231026164915.png)
