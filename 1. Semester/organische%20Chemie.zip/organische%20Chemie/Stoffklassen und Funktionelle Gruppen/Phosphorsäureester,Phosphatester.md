- Phosphor mit 4 Bindenden Atomen:
![](Pasted%20image%2020231026173834.png)
bei einem Rest: Monophosphat-Ester
bei zwei Resten: Diphosphat-Ester

- z.B. Rückgrad der DNA/RNA 