- an der Carbonylgruppe hängt neben dem Rest ein Amid:
![](Pasted%20image%2020231026172721.png)
--> bei Aminosäuren zu finden 
![](Pasted%20image%2020231026172750.png)
