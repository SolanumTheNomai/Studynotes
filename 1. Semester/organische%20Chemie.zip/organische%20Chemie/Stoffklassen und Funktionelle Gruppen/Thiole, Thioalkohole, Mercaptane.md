- besitzen eine SH-Gruppe (Thiolgruppe/Mercaptogruppe)
--> Disulfidbindungen zwischen anderen SH-Gruppen mittels Oxidation 
--> flüchtige Thiole stinken 
![](Pasted%20image%2020231026170050.png)
