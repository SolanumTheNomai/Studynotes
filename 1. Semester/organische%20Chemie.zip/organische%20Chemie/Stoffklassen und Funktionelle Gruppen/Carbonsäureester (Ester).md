- durch Wasserabspaltung --> Veresterung von der Carboxylgruppe mit einen Rest:
![](Pasted%20image%2020231026172221.png)
- leicht flüchtig, fruchtiger Geruch