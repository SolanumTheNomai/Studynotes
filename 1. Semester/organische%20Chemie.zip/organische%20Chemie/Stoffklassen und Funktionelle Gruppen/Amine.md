- besitzen Aminogruppen
- eingeteilt in:
![](Pasted%20image%2020231026171220.png)
--> abhängig von den Anzahlen der Reste

--> sind Basen (reagieren basisch, sind aufgrund des Stickstoffatoms Protonenakzeptoren)