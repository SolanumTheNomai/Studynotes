- Alkane mit einen Halogen als Anhang (Fluor, Chlor, Brom, Iod)
- Halogene im Molekül lassen sich gut mit einer anderen Gruppe substituieren 
![](Pasted%20image%2020231026165620.png)
