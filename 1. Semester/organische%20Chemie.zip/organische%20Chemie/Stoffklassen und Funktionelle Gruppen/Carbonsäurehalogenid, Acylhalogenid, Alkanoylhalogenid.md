- Carbonylgruppe wird neben den Rest mit einem Halogen verknüpft
- sehr reaktiv
![](Pasted%20image%2020231026172631.png)
