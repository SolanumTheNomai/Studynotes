- Fusion von 2 Carbonsäuren durch die OH-Gruppe --> Kondensation 
- sehr reaktiv
![](Pasted%20image%2020231026172401.png)
