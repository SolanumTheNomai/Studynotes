- sind Stickstoffatome (positiv) mit einen Rest und zwei Sauerstoffatomen (eins negativ)
--> Moleküle mit hohen Anteil an Nitrogruppen sind explosiv 
![](Pasted%20image%2020231026173720.png)