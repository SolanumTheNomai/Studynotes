![](Pasted%20image%2020231026173014.png)
--> haben neben der Carbonylgruppe auf beiden Seiten NH-Gruppen mit Resten 
![](Pasted%20image%2020231026173106.png)
