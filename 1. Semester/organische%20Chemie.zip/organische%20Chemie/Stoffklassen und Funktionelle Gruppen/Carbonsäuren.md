- Besitzen neben der Carbonyl-Gruppe eine Hydroxygruppe --> Carboxylgruppe 
--> saure Reaktion 
![](Pasted%20image%2020231026172108.png)
