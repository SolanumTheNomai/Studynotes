- derivat = "Abtrünniger"
- Derivat am Aromaten 
![](Pasted%20image%2020231026165304.png)
