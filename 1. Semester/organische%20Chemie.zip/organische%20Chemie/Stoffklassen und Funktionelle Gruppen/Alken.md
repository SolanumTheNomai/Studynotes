- Doppelbindung an C-Atomen als funktionelle Gruppe 
- reaktiv bei der Aufspaltung der pi-Bindungen (relativ schwache Bindungen)
![](Pasted%20image%2020231026165051.png)
(Ethen)