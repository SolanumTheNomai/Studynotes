- neben der Carbonyl-Gruppe ein Rest + ein H-Atom 
--> Reaktiv 
![](Pasted%20image%2020231026171703.png)
