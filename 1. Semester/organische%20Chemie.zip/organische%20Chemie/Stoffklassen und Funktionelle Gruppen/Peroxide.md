- besitzen zwei Sauerstoffe an zwei Resten 
- schwache O-Bindungen --> zersetzen schnell und explosionsartig
![](Pasted%20image%2020231026170757.png)
