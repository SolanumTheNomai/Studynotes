- keine funktionelle Gruppe
- unpolar, wenig reaktiv aber brennbar
![](Pasted%20image%2020231026164728.png)
