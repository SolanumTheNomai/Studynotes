- Schwefel zwischen zwei Resten
--> flüchtig haben sie einen unangenehmen Geruch (wie bei Thiole)
![](Pasted%20image%2020231026170453.png)
