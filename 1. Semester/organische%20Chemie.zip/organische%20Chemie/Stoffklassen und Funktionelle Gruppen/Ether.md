- Sauerstoff zwischen zwei Resten (Alkoxygruppe)
- relativ unreaktiv 
![](Pasted%20image%2020231026170231.png)
