- Schwefelatom mit einer Hydroxygruppe, zwei Doppelgebundene Sauerstoffatome + einen Rest 
--> reagieren sauer
![](Pasted%20image%2020231026173513.png)
