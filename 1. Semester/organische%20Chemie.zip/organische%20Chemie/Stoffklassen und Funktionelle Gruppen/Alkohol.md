- Hydroxygruppe als funktionelle Gruppe 
--> Ausbildung von H-Brückenbindung ermöglicht 
![](Pasted%20image%2020231026165824.png)
