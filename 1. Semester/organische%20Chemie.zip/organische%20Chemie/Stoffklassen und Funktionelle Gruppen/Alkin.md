- Dreifachbindung an C-Atomen als funktionelle Gruppe 
- reaktiv durch die Aufspaltung der pi-Bindungen (schwächere Bindungen)
![](Pasted%20image%2020231026165216.png)
