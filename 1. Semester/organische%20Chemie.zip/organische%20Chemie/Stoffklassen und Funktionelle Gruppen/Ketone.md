- besitzen neben der Carbonyl-Gruppe zwei Reste 
--> sehr reaktiv 
![](Pasted%20image%2020231026171923.png)
