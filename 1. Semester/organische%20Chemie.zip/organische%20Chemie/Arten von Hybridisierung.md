![](Pasted%20image%2020231019145709.png)
- Entstehung von 4 Hybridorbitalen in einer tetraedrischen Anordnung
- --> Winkel der benachbarten sigma-Orbitale: 109,5°
- --> 4-sigma-Bindungen 



![](Pasted%20image%2020231019151517.png)
- Entstehung von 3 Hybridorbitalen in einer trigonal planaren (Dreicksförmig, auf einer Ebene) Anordnung
- --> Winkel der benachbarten sigma-Orbitale: 120°
- --> 3 sigma-Bindungen, 1 pi-Bindung

![](Pasted%20image%2020231019164102.png)
- Entstehung von 2 Hybridorbitalen in einer linearen Anordnung
- --> Winkel der benachbarten sigma-Orbitale: 180°
- --> 2 sigma-Bindungen, 2 pi-Bindungen 