- beschreibt das Maß, wie stark ein [[Atom]] die bindenden Elektronen einer [kovalente Bindung](kovalente%20Bindungen.md)anzieht

- desto mehr Protonen im Atomkern existieren --> Elektronen werden stärker vom Kern angezogen --> höhere EN 
- desto mehr "Schalen" im Atom exisiteren --> größere Entfernung der Außenschale zum Kern --> schwächere Anziehungskraft anderer Elektronen --> niedrigere EN 

--> je höher die HG und je niedriger die Periode, desto höher die EN [EN](Elektronenegativität.md)
