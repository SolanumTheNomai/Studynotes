- 1:1 Mischung zweier [Enantiomere](Enantiomer.md) 
--> Drehwinkel heben sich gegenseitig auf --> optisch inaktiv

