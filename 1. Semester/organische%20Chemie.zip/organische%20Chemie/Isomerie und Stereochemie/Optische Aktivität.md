- eine Probe ist optisch aktiv, wenn das linear polarisierte Licht durch die Probe gedreht wird, sonst optisch inaktiv
![](Pasted%20image%2020231109114505.png)
- Drehung wird durch alle Moleküle in der Probe beeinflusst 