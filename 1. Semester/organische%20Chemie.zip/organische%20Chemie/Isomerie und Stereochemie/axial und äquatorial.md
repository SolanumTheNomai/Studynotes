- Axial: Verbindung in einem cyclischen-/Heterocyclischen-Ring, sind nach oben/unten orientiert 

- Äquatorial: Verbindung in einem cyclischen-/Heterocyclischen-Ring sind 90° von der axialen Verbindung orientiert 
![](Pasted%20image%2020231106174154.png)

- bei diesen Ringen bevorzugen große Substituenten die äquatoriale Position:
![](Pasted%20image%2020231106174313.png)

