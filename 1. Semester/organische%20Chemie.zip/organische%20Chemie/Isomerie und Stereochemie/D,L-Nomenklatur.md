- Einteilung von Moleküle in der Fischer-Projektion:

- Zeichnung des Moleküls:
	1. längste C-Kette wird vertikal gezeichnet 
	2. Kohlenstoff mit der höchsten Oxidationsstufe steht am oberen Ende der Kette 
	3. nur das asymmetrisch substituierte C-Atom, welches am weitesten vom oberen Ende entfernt ist, hat Relevanz bei der Benennung:
		- Substituent steht rechts: D-...
		- Substituent steht links: L-...