- Moleküle mit mehreren Stereozentren können eine interne Spiegelebene besitzen --> sind achiral --> meso Verbindung:
![](Pasted%20image%2020231113164239.png)
