- [Isomere](Isomere.md) welche sich in der Konnektivität der Atome:
![](Pasted%20image%2020231030165229.png)
