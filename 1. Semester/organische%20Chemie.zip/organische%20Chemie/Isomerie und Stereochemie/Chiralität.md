- Spiegelbild des Objektes (z.B. Moleküle) sind nicht Deckungsgleich

- Moleküle sind chiral, wenn sie keine Symmetrieebene/Symmetriezentrum haben 