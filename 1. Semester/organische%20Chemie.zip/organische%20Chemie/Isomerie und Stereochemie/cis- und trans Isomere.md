- Konfigurationsisomere
- Diastereomere, welche zwei verschiedene Formen annehmen können:
![](Pasted%20image%2020231207115310.png)
--> aufgrund der Sterischen Hinderung --> Trans-Isomer bevorzugt 