- Anteil des Überschussisomers in % - Anteil des Unterschussisomers in 
![](Pasted%20image%2020231109115005.png)

