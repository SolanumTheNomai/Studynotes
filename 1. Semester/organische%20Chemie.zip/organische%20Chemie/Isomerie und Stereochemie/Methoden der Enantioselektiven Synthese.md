- Nutzung eines chiralen Katalysators (chemischer Weg)
--> nur bestimmtes Enantiomer wird umgesetzt:
![](Pasted%20image%2020231116172928.png)

- Nutzung von Mikroorganismen oder Enzymen (biologischer Weg)
![](Pasted%20image%2020231116173021.png)

- chiral pool-Synthese:
	- Nutzung von Naturstoffen, als enantiomerreine Stoffe als Edukt/Auxiliar für die Reaktion --> nur ein Enantiomer als Produkt 