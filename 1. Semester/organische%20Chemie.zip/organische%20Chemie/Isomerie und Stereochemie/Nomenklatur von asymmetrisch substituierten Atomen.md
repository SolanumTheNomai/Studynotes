- R/S-Sequenzregel

![](Pasted%20image%2020231109163239.png)
![](Pasted%20image%2020231109163423.png)
