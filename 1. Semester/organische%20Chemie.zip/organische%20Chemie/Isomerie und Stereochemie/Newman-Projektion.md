- mit der Projektion kann man Rotamere anschaulich darstellen 
![](Pasted%20image%2020231030165518.png)
