- Verschiedene Konformationsisomere können durch Drehung um Einfachbindungen ineinander überführt werden:
![](Pasted%20image%2020231030165400.png)
--> die gestaffelte Anordnung ist energetisch günstiger, als die Ekliptische Anordnung, da die Abstoßung durch die Valenzelektronen der einzelnen Atome im Molekül geringer sind 