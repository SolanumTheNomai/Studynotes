- beschreibt den Drehwinkel des Lichts 
- ist abhängig von der Konzentration der Probe, Wellenlänge des Lichts, ...

- spezifischer Drehwert: charakteristische Größe für die Substanz, wo alle anderen Abhängigkeiten rausgerechnet werden --> Bestimmung der Probe
![](Pasted%20image%2020231106180043.png)
