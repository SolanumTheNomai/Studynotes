**- Spontane Kristallisation** --> Sortierung der Enantiomerkristalle 
	--> sehr ungeanau und nicht skalierbar

**- chemische Spaltung mit chiralen Hilfsmitteln (Auxiliaren):**
- Nutzung eines chiralen Hilfstoff um die Enantiomeren zu Diastereomere reagieren zu lassen --> Trennung der Diastereomere mittels unterschiedlicher chemischen- und physikalischen Eigenschaften --> Rückumwandlung in die Enantiomere
- Bsp:
![](Pasted%20image%2020231116171312.png)

**- chirale Chromatographie:**
	- Nutzung einer chiralen stationären Phase --> mobile Phase (Enantiomerlösung) passiert die stationäre Phase --> ein Enantiomer erfährt stärkere intermolekulare Wechselwirkungen mit der stationären Phase als das andere Enantiomer --> passiert schneller/langsamer den Chromatographen --> Trennung der Enantiomere 

**- Racemattrennung mithilfe von Enzymen:**
	- durch Enzyme (als chiraler Katalysator): nur ein Enantiomer reagiert zum gewünschten Endprodukt --> Trennung möglich da es keine Enantiomere mehr sind:
	![](Pasted%20image%2020231116172536.png)

