- dargestellte Raumstruktur der Moleküle ist vereinfacht:
	- Asymmetrisch substituierte Kohlenstoffatome werden als Kreuz dargestellt 
	- horizontale Bindungen sind auf dem Betrachter gerichtet
	- vertikale Bindungen weisen vom Betrachter weg 
--> Anwendung: bei einigen Biomolekülen (z.B. Kohlenhydraten, Aminosäuren)
![](Pasted%20image%2020231113162741.png)
