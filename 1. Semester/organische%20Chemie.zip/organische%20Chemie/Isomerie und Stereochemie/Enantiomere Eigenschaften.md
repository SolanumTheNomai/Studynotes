- gleiche physikalische- und chemische Eigenschaften (z.B. gleiche Löslichkeiten, gleiche Siedepunkte,...)

- Ausnahme von Oben: zwei Enantiomere verhalten sich bei linear polarisierten Licht unterschiedlich 
	--> ein E. dreht das Licht mit einem bestimmten Winkelbetrag in die eine Richtung
	--> das andere E. dreht das Licht mit dem gleichen Betrag in die entgegengesetzte Richtung (linksdrehend/rechtsdrehend)
