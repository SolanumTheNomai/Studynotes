![](Pasted%20image%2020231106175504.png)
- in einer Küvette ein bestimmter Stoff in einer Lösung (Probe) gebracht 
- Lichteinstrahlung in die Küvette 
--> Polarisationsfilter filtert das Licht, sodass das Licht sich nur noch auf einer Ebene befindet
--> Interaktion mit dem gelösten Stoff --> wenn das Licht gedreht wurde: Probe ist optisch aktiv 