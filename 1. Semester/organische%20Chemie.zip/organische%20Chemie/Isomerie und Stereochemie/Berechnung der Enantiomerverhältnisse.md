![](Pasted%20image%2020231109120059.png)
Bsp.:
![](Pasted%20image%2020231109120115.png)
