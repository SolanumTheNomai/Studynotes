M = m/n 
- M = molare Masse (Masse des Moleküls, wenn man von einer Stoffmenge von 1 mol aus)
- m = masse
- n = Stoffmenge (Teilchenzahl in mol)