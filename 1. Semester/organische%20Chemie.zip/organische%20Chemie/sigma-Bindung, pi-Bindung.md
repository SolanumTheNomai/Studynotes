- sigma-Bindung:
	- Orbitale überlappen sich entlang der Kern-Kern-Verbindungsachse
--> stabilere chemische Bindung 
![](Pasted%20image%2020231016163423.png)


- pi-Bindung:
	- Orbitale überlappen sich seitlich der Kern-Kern-Verbindungsachse
--> instabiliere chemische Bindung
![](Pasted%20image%2020231016163447.png)
--> dadurch ist das Molekül in seiner Drehbarkeit eingeschränkt 