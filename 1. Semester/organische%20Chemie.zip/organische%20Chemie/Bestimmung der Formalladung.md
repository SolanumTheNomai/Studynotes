
1. Teile alle Bindungen der Atome gleichmäßig auf --> 
2. Zähle dessen Valenzelektronen 
--> wenn diese nun mehr oder weniger Valenzelektronen besitzen 
--> Formalladung 