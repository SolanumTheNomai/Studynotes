![[Pasted image 20231009165114.png]]
- an den Enden: CH3
- an den Ecken: CH2
- wenn an der Bindung eine andere Gruppe rangehangen wurde: nur diese chem. Gruppe 