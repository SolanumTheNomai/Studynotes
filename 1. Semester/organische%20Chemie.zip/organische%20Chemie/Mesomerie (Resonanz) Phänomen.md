- es gibt Fälle, wo die Bindungsverhältnisse nicht absolut zuzuordnen sind, da bei unterschiedlichen Bediungen die Elektronenverteilung sich unterscheiden können:
![](Pasted%20image%2020231012183829.png)
