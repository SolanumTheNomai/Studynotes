- aufgebaut aus Atomkern ([[Protonen]] und [[Neutronen]]) und Atomhülle ([[Elektronen]])

- werden mit einer [[Ordnungszahl]] und einer [[Massezahl ]] definiert 