1. Klasse:
	- gesättigte Verbindungen:
		- keine C-C Mehrfachbindungen
	- ungesättigte Verbindungen:
		- min. eine C-C Mehrfachbindung

2. Klasse:
	![](Pasted%20image%2020231023173858.png)

3. Klasse:
	![](Pasted%20image%2020231023173922.png)

--> jedes organische Molekül kann in alle 3 Klassen eingeteilt werden 