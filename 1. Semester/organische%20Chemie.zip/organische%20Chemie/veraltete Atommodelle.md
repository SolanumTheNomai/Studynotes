![](Pasted%20image%2020231016160817.png)
![](Pasted%20image%2020231016160830.png)
![](Pasted%20image%2020231016160840.png)
