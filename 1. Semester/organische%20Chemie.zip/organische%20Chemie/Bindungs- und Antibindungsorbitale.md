- wenn zwei Elektronenorbitale in gleicher Phase zueinander überlappen --> Entstehung von Bindungsorbitalen 
- wenn zwei Elektronenorbitale in gegensätzlicher Phase überlappen --> Entstehung von Antibindungsorbitalen:
![](Pasted%20image%2020231016163016.png)
--> Bindungsorbitale sind energetisch günstiger --> werden zuerst besetzt 