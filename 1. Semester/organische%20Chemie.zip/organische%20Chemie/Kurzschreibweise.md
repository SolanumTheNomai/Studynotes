![[Pasted image 20231009165016.png]]
