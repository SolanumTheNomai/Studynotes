- Quantenmechanik
- Elektronen im Atom werden mithilfe mathematischer Gleichungen beschrieben:
![](Pasted%20image%2020231016161028.png)
--> mit den Gleichungen kann man den [[Energiezustand der Orbitale]], sowie die [[Aufenthaltswahrscheinlichkeit der Elektronen]] beschreiben 