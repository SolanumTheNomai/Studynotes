- HOMO-LUMO-Abstand nimmt mit der Anzahl der konjugierten pi-Elektronen ab 


--> je größer das pi-Elektronensystem, desto geringer ist die Energiedifferenz --> desto größer ist die Wellenlänge des Lichts welche das Molekül aufnehmen kann --> Molekül erhält seine Farbigkeit durch die Größe des konjugierten pi-Elektronensystems:
![](Pasted%20image%2020231218180848.png)
