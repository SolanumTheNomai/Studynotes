- Elektronen eines Moleküls können durch Licht der passenden Wellenlänge angeregt werden --> Übergang von HOMO --> LUMO
--> Anregungsenergie wird absorbiert --> fehlt im Spektrum --> man erhält nur das "Komplementärspektrum (Komplementärfarbe)"
![](Pasted%20image%2020231218180549.png)
![](Pasted%20image%2020231218180557.png)
