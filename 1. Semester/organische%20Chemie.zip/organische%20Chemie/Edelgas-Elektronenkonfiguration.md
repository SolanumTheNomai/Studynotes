- beschreibt das Bestreben der Elemente eine stabile Edelgaskonfiguration von 2, 8, bzw. 18 [[Valenzelektronen]] zu ereichen (abh. von der [[Periode]])

- jedoch: ([[Anomalie der Oktettregel]])