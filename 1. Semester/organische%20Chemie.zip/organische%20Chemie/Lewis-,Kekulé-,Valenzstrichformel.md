![[Pasted image 20231009164935.png]]
