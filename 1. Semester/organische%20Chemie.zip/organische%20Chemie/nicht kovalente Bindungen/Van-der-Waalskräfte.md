- dipol-dipol-Wechselwirkungen
	- Moleküle mit permanenten Dipol (Partialladung)
	- --> schwächere Dipole, als bei den [Wasserstoffbrücken-Bindungen](Wasserstoffbrücken-Bindungen.md)
	![](Pasted%20image%2020231019170658.png)

- Dipol-induzierter-Dipol-Wechselwirkungen
	- Molekülen mit permanenten und induzierten Dipol 
	- --> Partialladung des einen Molekül sorgt für die Entstehung einer Partialladung eines vorher unpolaren Moleküls 

- [London-Kräfte/Dispersionskräfte](Van%20der%20Waalskräfte%20Funktionsweise.md)

