- wenn zwei Moleküle unterschiedliche ionische Bindungen besitzen --> ionische Wechselwirkung gegenseitige Anziehung der Ionen (Salzbrücke)
![](Pasted%20image%2020231019170457.png)
