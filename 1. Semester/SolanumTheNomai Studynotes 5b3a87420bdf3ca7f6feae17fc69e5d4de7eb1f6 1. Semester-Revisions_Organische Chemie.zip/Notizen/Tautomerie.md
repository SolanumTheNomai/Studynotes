- Definition: Isomerieform (Konstitutionsisomer) bei den die Lage der DB und des Protons variiert 

 