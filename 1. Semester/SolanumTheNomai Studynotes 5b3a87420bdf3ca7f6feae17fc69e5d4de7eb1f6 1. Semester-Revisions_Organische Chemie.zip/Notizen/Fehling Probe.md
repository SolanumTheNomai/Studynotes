- Nachweis von reduzierenden Zuckern (Aldehyde) --> Oxidation des Aldehyds zur Carbonsäure und Reduktion des Kupfers --> Farbänderung & Ausfällen 

- nur bei Zuckern mit einer Aldehydgruppe, welche bei Ringöffnung exponiert ist 
