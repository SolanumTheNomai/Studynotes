- bei chem. Reaktion: gewinn von Racematen, kann man schwierig trennen:

- Racemattrennung:
	- Trennung von Enantiomerkristallen
	- chemische Synthese durch chirale Auxiliaren:
		- Enantiomer --> chirales Hilfsmittel --> Bildung von Diastereomeren --> Trennung --> Rückreaktion in die getrennten Enantiomore 
	- chirale Säurenchromatographie 
		- stationäre Phase: chirales Moleküle --> Probe (mobile Phase kommt durch den Säulenchromatographen --> ein Enantiomer erfährt geringere intermolekulare WW --> Trennung der Enantiomere)
	- Racemattrennung durch Enzyme:
		- Enzym reagiert nur mit einem Enantiomer, da chiral und damit stereospezifisch --> Produkt + Enantiomer liegt vor --> Trennung 

- Enantioselektive Synthese: 
	- nur ein Enantiomer werden gebildet 
	- biologischer Weg --> mit Enzymen
	- chemischer Weg --> mit chiralen Katalysatoren 