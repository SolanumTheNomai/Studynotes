- Flüssigpeptidsynthese: Aminosäuren müssen durch Schutzgruppen geschützt werden, damit sie nicht willkürlich reagieren --> nach selektiver Abspaltung der Schutzgruppen --> gezielte Peptide mit DCC --> sehr aufwendig 


- Festphasenpeptidsynthese:
	- mit Harzkügelchen --> gebunden ist ein Chloridmolekül --> sehr reaktiv --> Bindung der Carbonsäure an das Molekül mit der Nucleophilen Substitution --> Entschützung der Aminogruppe --> zweite Aminosäure wird angeknüpft mit DCC --> Vorgang wiederholt sich 


- Vorteile:
	- dabei kann eine große Menge an Reagenzien phasenweise in die Reaktion integriert werden, da überschüssige Reagenzien ausgewaschen werden können hohe Ausbeute 
	- --> Automatisierung möglich 

- Nachteile:
	-  Reaktionsgeschwindigkeit durch die eingeschränkte Oberfläche an den Harzkugeln rel. gering 
	- einfache Analytische Methoden, zur Analyse der Reaktion, wie Dünnschichtchromatographie nicht möglich, da die Zwischenprodukte an dem Harz gebunden sind 
	- hohe Konzentration an Trägermaterial nötig 

