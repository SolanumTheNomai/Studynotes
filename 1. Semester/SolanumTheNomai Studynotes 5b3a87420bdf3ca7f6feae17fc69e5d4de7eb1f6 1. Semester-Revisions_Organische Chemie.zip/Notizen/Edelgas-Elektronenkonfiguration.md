- bei Atomen der zweiten Periode: 8 Plätze für Valenzelektronen 
--> um die Oktettregel zu erfüllen: alle Plätze müssen gefüllt werden: 
	- durch freie Elektronenpaare (auch durch Ionenbindungen) möglich
	- durch kovalente Bindungen
	--> wenn nicht --> "Elektronenlücke"

--> Entstehung von Formalladungen bei Bindungen:
	1. Zählen der Valenzelektronen des Atoms
	2. Zählen der Bindungen (Teilen) und der lone pairs (2) --> Formalladung 



