- sind schwache Säuren --> pKs-Wert (Wert an den die Konzentration zwischen der Säure und der korrespondierenden Base 1:1 ist) ist relativ hoch 

--> Carbonsäuren können als Puffer wirken:
	- bei der Titrationskurve erkennt man den Anstieg des pH-Werts abhängig von der Natriumlauge-Konzentation --> an bestimmten Bereichen steigt der pH-Wert kaum an, da an dieser Stelle die Carbonsäure zum Carboxylat reagiert --> Freisetzung von Protonen --> Regulierung des pH-Werts

- pH-Wert kann mit der Hasselbach-Gleichung berechnet werden 