- Zwei Formen:
	- E1-Reaktion:
	- Reagenzien: tertiärer Alkohol, verdünnte  Phosphatsäure + 50°C
	- Mechanismus: tertiärer Alkohol wird protoniert --> Wasser wird eliminiert --> Carbeniumion --> Molekül wird deprotoniert --> Alken (Dehydratisierung)

	- E2-Reaktion:
	- Reagenzien: primärer Alkohol, konzentrierte Phosphorsäure + 170°
	- Mechanismus: primärer Alkohol wird protoniert --> Wasser verlässt das Molekül, während das Molekül deprotoniert --> Alken (Dehydratisierung)
