- Zusammensetzung von Aminosäuren mit einen N-Terminus und einen C-Terminus 

- Peptidbindung: C-N-Bindung --> Mesomeriestabilisierung durch eine partielle DB zwischen C-N und C-O bei der Carboxylgruppe --> geringe Flexibilität 