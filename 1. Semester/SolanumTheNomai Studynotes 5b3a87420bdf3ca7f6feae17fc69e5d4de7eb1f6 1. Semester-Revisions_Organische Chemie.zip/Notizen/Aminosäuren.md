- haben eine Carbonsäure, ein Amin und Wasserstoff und einen Rest --> können sowohl als Basen, als auch als Säure reagieren (amphoterer Charakter)

--> an der Stelle wo Protonenwanderungen stattfinden --> Pufferzone 


- Isoelektrischer Punkt: pH-Wert an denen die meisten Teilchen keine Nettoladung besitzen 

- Löslichkeit: Zwitterionen schlechter Löslich 