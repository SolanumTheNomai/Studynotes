- es gibt theoretisch zwei formen: cis/trans und E/Z
--> E/Z kann man immer einsetzen, cis/trans nicht
--> E/Z sollte man bestenfalls anwenden falls nötig:

- Vorgehensweise: Ausrichtung der höher priorisierten Substituenten beachten:
- gleiche Richtung --> zusammen --> Z
- entgegengesetzte Richtung --> entgegen --> E 
- bei Ringsubstituenten oder beim Fall, dass beide Substituenten identisch sind --> keine E/Z-Nomenklatur erforderlich 