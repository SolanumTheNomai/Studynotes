- bei bestimmten Molekülen ist die Elektronenverteilung innerhalb des Moleküls nicht mit einer Strukturformel bestimmbar:
	- bei Atomen mit Elektronenlücken
	- bei pi-Bindungen 
	- bei freien Elektronenpaaren 

--> Zeichnen von Mesomeren Strukturen (!Achtung!: Oktettregel)
- je mehr Mesomere Strukturen man zeichnen kann desto delokalisierter sind die Elektronen im Molekül --> stabiler (Mesomeriestabilisierung)

- Relevanz der Mesomerie: 
	1. jedes Atom hat die Oktettregel erfüllt
	2. keine Ladungen 
	3. Ladungen eher bei Atomen mit höherer EN 

