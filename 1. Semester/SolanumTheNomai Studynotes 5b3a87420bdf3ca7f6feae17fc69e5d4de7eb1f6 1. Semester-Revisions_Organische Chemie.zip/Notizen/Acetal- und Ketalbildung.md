- Acetal: Reaktion von Aldehyd und Alkohol:
- Protonierung des Aldehyds --> pos. geladener Sauerstoff --> Bildung eines Carbeniumions --> Alkohol bindet an das Carbeniumion  --> deprotonierung --> Halbacetal --> protonierung des Alkohols --> Wasserabspaltung --> Carbeniumion --> Addition durch ein Alkohol --> Vollacetal 

- bei Ketonen: gleiches Prinzip 