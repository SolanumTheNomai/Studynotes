- Zusammensetzung: a-Amylose und Amylopektin 

- beide sind innerhalb der Hauptkette mit einer a-1,4-glykosidischen Bindung verbunden --> helikale Anordnung --> wasserlöslich 

- Amylopektin besitzt noch Seitenketten (a-1,6-glykosidische Bindungen) alle 24-32 Glucoseeinheiten 


--> Speicherpolysaccharid