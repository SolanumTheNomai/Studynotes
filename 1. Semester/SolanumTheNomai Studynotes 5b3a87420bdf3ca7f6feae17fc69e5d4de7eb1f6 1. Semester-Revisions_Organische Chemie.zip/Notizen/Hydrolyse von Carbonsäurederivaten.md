- Mechanismus: Additions-Eliminierungs-Mechanismus mit Wasser
--> bei: Anhydriden, Halogeniden --> schnelle Reaktion
--> bei Estern, Amiden --> langsame Reaktion

--> Entstehung von Carbonsäuren und Rest 


- Reaktion bei Estern: 
	- Säurekatalysiert oder basische Verseifung 

