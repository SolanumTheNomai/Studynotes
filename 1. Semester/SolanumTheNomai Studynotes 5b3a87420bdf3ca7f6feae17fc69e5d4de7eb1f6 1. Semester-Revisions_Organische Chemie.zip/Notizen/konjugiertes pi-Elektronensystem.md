- Wechsel zwischen Einfach- und Doppelbindung --> Entstehung von pi-Bindungen und schwache pi-Überlappungen --> Delokalisertes pi-Elektronensystem --> Mesomeriestabilisierung und  sehr starre Struktur 



- Zusammenhang mit Farbigkeit: 
	- bei steigender Größe des pi-Elektronensystems --> Abstand zwischen dem HOMO-LUMO sinkt --> Elektronen brauchen immer weniger Energie um diesen Zustand zu wechseln --> ab einen bestimmten Punkt: Absorbtion von Licht in Wellenlängen im sichtbaren Bereicht --> Komplementärfarbe ist zu sehen 