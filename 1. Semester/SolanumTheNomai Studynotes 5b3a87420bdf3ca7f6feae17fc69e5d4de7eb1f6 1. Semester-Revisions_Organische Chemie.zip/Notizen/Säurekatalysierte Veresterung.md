- Protonierung der Carbonsäure --> Carbeniumion --> Addition eines Alkohols --> Deprotonierung --> zweiwertiger Alkhohol --> Protonierung --> Wasserabspaltung --> Carbeniumion --> Deprotonierung --> Carbonsäure
![](Pasted%20image%2020240219145126.png)
