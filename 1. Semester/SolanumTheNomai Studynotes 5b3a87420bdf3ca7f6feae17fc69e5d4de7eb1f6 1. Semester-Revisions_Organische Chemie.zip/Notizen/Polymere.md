- Definition: Molekül zusammengesetzt aus vielen identischen Monomereinheiten 

- Herstellung von künstlichen Polymeren: Alkene + Radikale 