- [C*(H20)]n ab n<=3


- Aufbau von Monosacchariden:
	- entweder Aldehyd oder Keton --> Substituenten von den restlichen C-Atomen: Alkohole und Wasserstoff

- Klassifizierung:
	- Aldehyd: Aldose
	- Keton: Ketose
	- Anzahl an C-Atomen: Triose, Tetrose,....
	- in Ringform: Furanose (Fünfring) und Pyranose (Sechsring)
