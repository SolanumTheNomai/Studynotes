- sonst: Säure-Base Reaktion (Amidbildung sehr selten unter hoher Hitze)

- mit einer Kupplungsreagenz (Dicyclohexylcarbodiamid --> DCC) kann das Carboxylat im basischen Milleu in eine gute Abgangsgruppe überführt werden --> Aditions-E. Mech. --> Amidbildung mit einer stabilen Abgangsgruppe:
![](Pasted%20image%2020240219145721.png)
