- bei Prio: Alkan-al/-on
- bei fehlender prio: Oxo

