- Hydrierung: Alken wird zum Alkan mittels H2:
- Katalysator: Palladium/Kohlenstoff, Platin, Nickel 
- Mechanismus: Wasserstoff bindet an den Katalysator --> Wasserstoffbindung bricht --> WW von Katalysator und Alken --> Wasserstoff reagiert mit Alken --> Verlust der DB --> zweites H addiert sich zum Zwischenprodukt --> Alkan



- Addition von Wasser/HX
	- Mechanismus: Proton von HX bindet an Kohlenstoff --> DB bricht --> Carbeniumion (ist am stabilsten, wenn sich das Proton an das C-Atom mit den wenigerer Substituenten anlagert (Markownikow-Regel)) --> Halogen bindet ans Carbeniumion

	- bei Wasser: Säure als Protonendonator notwendig (Säure, welches ein schlechtes Nucleophil ist, damit es nicht mit dem Wasser als Konkurrenz gegenübersteht)
	- Grund, warum Phosphorsäure ein schlechtes Nucleophil ist:
		- Größe --> hohe sterische Hinderung 
		- dreifach neg. geladen --> Hydrathülle --> sterische Hinderung 
		- Mesomeriestabiliert --> weniger reaktiv 
	- Mechanismus: Protonierung des Alkens --> Carbeniumion --> Addition von Wasser --> positiv geladener Sauerstoff --> Deprotonierung des Moleküls --> Alkohol 



- Epoxierung: 
	- Mechanismus:
		- Sauerstoff der Persäure löst sich und bindet an dem beiden C-Atomen des Alkens --> Epoxidbildung + Carbonsäure 

