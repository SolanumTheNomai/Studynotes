- Sortierung nach Stärke
	- Ionische WW
		- bei geladenen Molekülen 
	- H-Brücken-Bindungen
		- bei Existenz von H-Brückendonatoren (H-Atom in Bindung mit deutlich EN-stärkeren Atomen (z.B. O,N))
	- Dipol-Dipol-WW 
		- bei Dipolen im Molekül ohne Nettoladung 
	- London-Kräfte:
		- zufällige Verschiebungen der Elektronendichte 

- hat Auswirkungen auf die Siede-/Schmelztemperatur und Löslichkeit 

- Hydrophober Effekt
	- Beschreibt den Effekt das lipophile Moleküle sich im Wasser zusammenschließen:
		- Grund: einzelne Lipophile Moleküle mit Wasser umhüllt (Hydrathülle) --> große Kontaktfläche zwischen Wasser und hydrophobe Moleküle -->geringe Entropie --> energetisch ungünstig
		- Zusammenschließung der hydrophoben Moleküle --> geringere Kontaktfläche zwischen den Wasser --> hohe Entropie --> energetisch günstiger