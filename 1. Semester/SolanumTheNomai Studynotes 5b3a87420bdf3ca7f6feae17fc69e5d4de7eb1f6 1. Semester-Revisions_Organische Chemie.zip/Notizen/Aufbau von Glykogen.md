- Glykogen besitzt ebenfalls a-1,4-gly. Bindungen in der Hauptkette und a-1,6-gly. Bindungen in der Seitenkette, sie sind mit 8-12 Glucoseeinheiten aber häufiger vertreten --> schnellere Mobilisierung der Glucose (wichtig für Tiere z.B. für den fight/flight Mechanismus)

--> Speicherpolysaccharid


