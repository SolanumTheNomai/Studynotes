- bei verzweigten Alkanen:
	1. längste C-Kette suchen (wenn zwei gleichlange C-Ketten existieren --> den mit den meisten Substituenten auswählen)
	2. C-Atome nummerieren (beginnend mit der Seite, welche einem Substituenten am nächsten ist, wenn beide Seiten gleichen Beginn haben --> kleinste Summe bei den Substituenten)
	3. Substituenten erkennen und benennen (Alkyl-Reste, Nitroverbindungen, Halogenverbindungen, Alkoxyverbindungen,...)
	4. Nummerierung der Substituenten (alphabetisch, wenn zwei gleiche Substituenten = x,y + di,tri,..., wenn verschachtelte Substituenten = x des hauptsubs, (y-Nebensub,hauptsubs))

- bei Alkoholen
	1. längste C-Kette mit Alkoholen suchen (bei gleichen Kettenlänge --> meiste Alkhole/meiste Subs)
	2. C-Atome zählen --> bei dem nächsten Alkohol beginnnen
	3. Subs zählen 
	4. Formel aufschreiben (Regel: siehe oben) x Alkan(n)ol
	!Achtung!: bei Verbindungen höherer Prioriät, als alkohol --> Hydroxy-...
