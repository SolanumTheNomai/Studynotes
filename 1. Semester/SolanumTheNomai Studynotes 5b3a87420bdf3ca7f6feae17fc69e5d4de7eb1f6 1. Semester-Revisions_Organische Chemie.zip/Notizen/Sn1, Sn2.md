- Sn1: Zwischenprodukte (Carbenium-Ion) --> geschwindigkeitsbestimmender Schritt, je mehr Substituenten an dem Ion gebunden sind --> stärkere Hyperkonjugation --> mehr Mesomere Formen --> Mesomeriestabilisierend (kommt bei Nucleophilen, mit mindestens 2 Subs vor)
- Reaktionsgeschw. abhängig vom Nuecleophil (unimolekular) v = k[R-X] --> bei Enantiomeren --> Racemisierung 

- Sn2: konzertiert (ohne Zwischenprodukt) --> Reaktionsgeschwindigkeit, von Nucleophil und und Edukt: v = k[RX][Nu-]
	- bei Enantiomeren --> änderung der Konfig (Waldenumkehr)
	- bei Edukten, mit geringer sterischer Hinderung (durch den Rückseiteangriff des Nucleophils)