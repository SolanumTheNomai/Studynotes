- Carbonsäuren:
	- Alkan-säure 
	- a/ß/gamma, für die Spezifizierung der Substituenten  


- Ester:
	- Alkyl-Alkanoat
	- Alkansäure-alkylester

- Amid:
	- N-Alkyl-Alkanamid


- Fettsäuren: 
	- (Anzahl an C-Atomen mit EB : Anzahl an C-Atomen mit DB, Delta "Stelle der "DB")
	- Omega --> rückwärtiges Zählen 


