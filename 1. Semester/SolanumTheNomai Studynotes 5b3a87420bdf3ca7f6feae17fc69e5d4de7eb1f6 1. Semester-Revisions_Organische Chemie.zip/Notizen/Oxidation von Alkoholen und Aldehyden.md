- Alkohol wird zum Aldehyd oxidiert (mithilfe von Pyridiniumchlorochromat in Dichlormethan als Lösungsmittel)
- Aldehyde können in Carbonsäuren oxidiert werden (mithilfe von Fehling I und II Lösung)

- weitere Oxidationsmittel:
	- CrO3, verdünnte Schwefelsäure mit Aceton, Kaliumpermanganat (KMnO4)

