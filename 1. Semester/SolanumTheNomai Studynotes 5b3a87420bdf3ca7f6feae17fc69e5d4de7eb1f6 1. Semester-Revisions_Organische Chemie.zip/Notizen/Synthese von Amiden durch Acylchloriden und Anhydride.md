- Amin greift Halogenid nucleophil an --> Addition --> Eliminierung der Abgangsgruppe --> Halogensäure und Amid
![](Pasted%20image%2020240219145403.png)
