- Zusammensatzung von zwei Monosacchariden, welche mit einer glykosidischen Bindung (Kondensationsreaktion) verbunden sind --> Wasserabspaltung innerhalb der Zelle ungünstig --> ATP notwendig für diese Reaktion 


- Arten von glykosidischen Bindungen:
- Verbindung zwischen welchen C-Atomen der Monosaccharide? 
- in welcher Konformation (a/ß)