- bei Iminen: Reaktion von Ketonen und primären Aminen oder Ammoniak:

- Amin greift Keton nucleophil an --> neg. geladenes Sauerstoffatom, pos. geladenes Amin --> Wasserstoffe werden auf den Sauerstoff addiert --> Eliminerung von Wasser mit einer DB zwischen dem Amin und dem Kohlenstoff

bei Enaminen: Reaktion von Ketonen und sekundären Aminen: 
- Amin greift Keton nucleophil an -> neg geladenes Sauerstoffatom, pos. geladenes AMin --> Wasserstoff des Amins wandert zum Sauerstoff --> Alkohol als Zwischenprodukt --> Protonwanderung von C-Atom zum Sauerstoff --> Wasser wird eliminiert --> DB-Bildung --> Enamin


- Reduktive Aminierung: 
	- Iminen sind häufig Zwischenprodukte --> Reduktion per Hydrierung --> DB wird gebrochen 

