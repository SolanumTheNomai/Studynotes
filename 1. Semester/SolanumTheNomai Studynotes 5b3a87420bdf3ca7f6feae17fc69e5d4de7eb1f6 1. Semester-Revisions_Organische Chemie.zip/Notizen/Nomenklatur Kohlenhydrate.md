- D,L-Nomenklatur --> bei Kohlenhydraten natürlicherweise die D-Form 

