- Bindung: ß-1,4-glykosidische Bindung --> lineare Anordnung --> Wasserstoffbrückenbindungen bilden sich zwischen den Ketten --> stabil und wasserunlöslich 

--> Strukturpolysaccharid 
